﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;
using System.Windows;
using System.Timers;

namespace Secundomer
{
    class Model
    {
        private DispatcherTimer TimerMS = null;
        private MainWindow mainWindow = null;
        public Model(MainWindow mainWindow)
        {
            this.mainWindow = mainWindow;
            TimerMS = new DispatcherTimer();
        }
        public void Ticking()
        {
            TimerMS.Interval = TimeSpan.FromMilliseconds(1);
            TimerMS.Tick += CountOf;
            TimerMS.Start();
        }
        public void Stop()
        {
            TimerMS.Stop();
        }
        public void Clear()
        {
            counterMS = 0;
            counterS = 0;
            counterMIN = 0;
            TimerMS.Stop();
            this.mainWindow.MillisecondsLabel.Content = counterMS;
            this.mainWindow.SecondsLabel.Content = counterS;
            this.mainWindow.MinutesLabel.Content = counterMIN;
        }

        private int counterMS = 0;
        private int counterS = 0;
        private int counterMIN = 0;
        private void CountOf(object sender, EventArgs e)
        {
            counterMS++;
            if (counterMS == 100)
            {
                counterMS = 0;
                counterS++;
            }
            if (counterS == 60)
            {
                counterMIN++;
                counterS = 0;
            }
            this.mainWindow.MillisecondsLabel.Content = counterMS;
            this.mainWindow.SecondsLabel.Content = counterS;
            this.mainWindow.MinutesLabel.Content = counterMIN;
        }

    }
}
