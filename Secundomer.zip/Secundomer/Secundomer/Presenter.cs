﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Secundomer
{
    class Presenter
    {
        Model model = null;
        MainWindow mainWindow = null;

        public Presenter(MainWindow mainWindow)
        {
            this.mainWindow = mainWindow;
            model = new Model(mainWindow);
            this.mainWindow.Start += new EventHandler(Secundomer_Start);
            this.mainWindow.Stop += new EventHandler(Secundomer_Stop);
            this.mainWindow.Clear += new EventHandler(Secundomer_Clear);
        }

        private void Secundomer_Start(object sender, EventArgs e)
        {
            model.Ticking();
        }
        private void Secundomer_Stop(object sender, EventArgs e)
        {
            model.Stop();
        }
        private void Secundomer_Clear(object sender, EventArgs e)
        {
            model.Clear();
        }
    }
}
